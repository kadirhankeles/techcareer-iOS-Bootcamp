import UIKit

var sehir: String = "İstanbul"
var ulke: String = "Türkiye"
var telefon: String = "555-555-5555"
var postaKodu: String = "34000"
var email: String = "ornek@email.com"
let meslek: String = "Bilgisayar Mühendisi"
let stokMiktari: Int = 100
let musteriAdi: String = "Kadirhan Keleş"
let bakiye: Double = 1500.50
let dogumGunu: String = "15/04/1985"
var maas: Double = 4500.75
var medeniDurum: String = "Bekar"
var urunYorum: String = "Ürün çok kaliteli!"
var odemeTarihi: String = "01/09/2023"
var odeme: Double = 500.0
let siparisAdeti: Int = 5
let arabaModeli: String = "Toyota Corolla"
let kitapAdi: String = "Yüzüklerin Efendisi"
let yayinlamaTarihi: String = "15/08/2022"
let indirimMiktari: Double = 50.0
var odaSayisi: Int = 3
var enlem: Double = 41.0055
var boylam: Double = 28.9744
var urunAdi: String = "Akıllı Telefon"
var yemekFiyatı: Double = 198.80
let marka: String = "Apple"
let muzikAdi: String = "Shape of You"
let videoSuresi: Double = 120.5
let urunPuani: Double = 4.5
let resimAdi: String = "manzara.jpg"
var dosyaFormati: String = "PDF"
var renk: String = "Mavi"
var renkKodu: String = "#0000FF"
var telefonModeli: String = "iPhone 13 Pro Max"
var ekranBoyutu: Double = 6.5
let agirlik: Double = 82.5
let ulusalGun: String = "29 Ekim"
let tatilGunu: String = "1 Mayıs"
let rezervasyonTarihi: String = "10/10/2023"
let sokakAdi: String = "Örnek Sokak"
let otobusHatti: String = "11L"
var kalanDakika: Int = 30
var takipKodu: String = "ABC123"
var kuponSüresi: String = "15/12/2023"
var kuponKodu: String = "DENEMEKOD"
var faturaAdresi: String = "İstanbul mah. kamil sok. altın apt. 23/5"



print("Şehir: \(sehir)")
print("Ülke: \(ulke)")
print("Telefon: \(telefon)")
print("Posta Kodu: \(postaKodu)")
print("E-mail: \(email)")
print("Meslek: \(meslek)")
print("Stok Miktarı: \(stokMiktari)")
print("Müşteri Adı: \(musteriAdi)")
print("Bakiye: \(bakiye) ₺")
print("Doğum Günü: \(dogumGunu)")
print("Maaş: \(maas) ₺")
print("Medeni Durum: \(medeniDurum)")
print("Ürün Yorum: \(urunYorum)")
print("Ödeme Tarihi: \(odemeTarihi)")
print("Ödeme: \(odeme) ₺")
print("Sipariş Adeti: \(siparisAdeti)")
print("Araba Modeli: \(arabaModeli)")
print("Kitap Adı: \(kitapAdi)")
print("Yayınlama Tarihi: \(yayinlamaTarihi)")
print("İndirim Miktarı: \(indirimMiktari)")
print("Oda Sayısı: \(odaSayisi)")
print("Enlem: \(enlem)")
print("Boylam: \(boylam)")
print("Ürün Adı: \(urunAdi)")
print("Yemek Fiyatı: \(yemekFiyatı) ₺")
print("Marka: \(marka)")
print("Müzik Adı: \(muzikAdi)")
print("Video Süresi: \(videoSuresi)")
print("Ürün Puanı: \(urunPuani)")
print("Resim Adı: \(resimAdi)")
print("Dosya Formatı: \(dosyaFormati)")
print("Renk: \(renk)")
print("Renk Kodu: \(renkKodu)")
print("Telefon Modeli: \(telefonModeli)")
print("Ekran Boyutu: \(ekranBoyutu) inç")
print("Ağırlık: \(agirlik) kg")
print("Ulusal Gün: \(ulusalGun)")
print("Tatil Günü: \(tatilGunu)")
print("Rezervasyon Tarihi: \(rezervasyonTarihi)")
print("Sokak Adı: \(sokakAdi)")
print("Otobüs Hattı: \(otobusHatti)")
print("Kalan Dakika: \(kalanDakika) dk")
print("Takip Kodu: \(takipKodu)")
print("Kupon Süresi: \(kuponSüresi)")
print("Kupon Kodu: \(kuponKodu)")
print("Fatura Adresi: \(faturaAdresi)")




