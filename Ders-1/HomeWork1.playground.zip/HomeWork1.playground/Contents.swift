import UIKit

var sehir: String = "İstanbul"
var ulke: String = "Türkiye"
var telefon: String = "555-555-5555"
var postaKodu: String = "34000"
var email: String = "ornek@email.com"
var meslek: String = "Bilgisayar Mühendisi"
var stokMiktari: Int = 100
var musteriAdi: String = "Kadirhan Keleş"
var bakiye: Double = 1500.50
var dogumGunu: String = "15/04/1985"
var maas: Double = 4500.75
var medeniDurum: String = "Bekar"
var urunYorum: String = "Ürün çok kaliteli!"
var odemeTarihi: String = "01/09/2023"
var odeme: Double = 500.0
var siparisAdeti: Int = 5
var arabaModeli: String = "Toyota Corolla"
var kitapAdi: String = "Yüzüklerin Efendisi"
var yayinlamaTarihi: String = "15/08/2022"
var indirimMiktari: Double = 50.0
var odaSayisi: Int = 3
var enlem: Double = 41.0055
var boylam: Double = 28.9744
var urunAdi: String = "Akıllı Telefon"
var yemekFiyatı: Double = 198.80
var marka: String = "Apple"
var muzikAdi: String = "Shape of You"
var videoSuresi: Double = 120.5
var urunPuani: Double = 4.5
var resimAdi: String = "manzara.jpg"
var dosyaFormati: String = "PDF"
var renk: String = "Mavi"
var renkKodu: String = "#0000FF"
var telefonModeli: String = "iPhone 13 Pro Max"
var ekranBoyutu: Double = 6.5
var agirlik: Double = 82.5
var ulusalGun: String = "29 Ekim"
var tatilGunu: String = "1 Mayıs"
var rezervasyonTarihi: String = "10/10/2023"
var sokakAdi: String = "Örnek Sokak"
var otobusHatti: String = "11L"
var kalanDakika: Int = 30
var takipKodu: String = "ABC123"
var kuponSüresi: String = "15/12/2023"
var kuponKodu: String = "DENEMEKOD"
var faturaAdresi: String = "İstanbul mah. kamil sok. altın apt. 23/5"



print("Şehir: \(sehir)")
print("Ülke: \(ulke)")
print("Telefon: \(telefon)")
print("Posta Kodu: \(postaKodu)")
print("E-mail: \(email)")
print("Meslek: \(meslek)")
print("Stok Miktarı: \(stokMiktari)")
print("Müşteri Adı: \(musteriAdi)")
print("Bakiye: \(bakiye) ₺")
print("Doğum Günü: \(dogumGunu)")
print("Maaş: \(maas) ₺")
print("Medeni Durum: \(medeniDurum)")
print("Ürün Yorum: \(urunYorum)")
print("Ödeme Tarihi: \(odemeTarihi)")
print("Ödeme: \(odeme) ₺")
print("Sipariş Adeti: \(siparisAdeti)")
print("Araba Modeli: \(arabaModeli)")
print("Kitap Adı: \(kitapAdi)")
print("Yayınlama Tarihi: \(yayinlamaTarihi)")
print("İndirim Miktarı: \(indirimMiktari)")
print("Oda Sayısı: \(odaSayisi)")
print("Enlem: \(enlem)")
print("Boylam: \(boylam)")
print("Ürün Adı: \(urunAdi)")
print("Yemek Fiyatı: \(yemekFiyatı) ₺")
print("Marka: \(marka)")
print("Müzik Adı: \(muzikAdi)")
print("Video Süresi: \(videoSuresi)")
print("Ürün Puanı: \(urunPuani)")
print("Resim Adı: \(resimAdi)")
print("Dosya Formatı: \(dosyaFormati)")
print("Renk: \(renk)")
print("Renk Kodu: \(renkKodu)")
print("Telefon Modeli: \(telefonModeli)")
print("Ekran Boyutu: \(ekranBoyutu) inç")
print("Ağırlık: \(agirlik) kg")
print("Ulusal Gün: \(ulusalGun)")
print("Tatil Günü: \(tatilGunu)")
print("Rezervasyon Tarihi: \(rezervasyonTarihi)")
print("Sokak Adı: \(sokakAdi)")
print("Otobüs Hattı: \(otobusHatti)")
print("Kalan Dakika: \(kalanDakika) dk")
print("Takip Kodu: \(takipKodu)")
print("Kupon Süresi: \(kuponSüresi)")
print("Kupon Kodu: \(kuponKodu)")
print("Fatura Adresi: \(faturaAdresi)")




